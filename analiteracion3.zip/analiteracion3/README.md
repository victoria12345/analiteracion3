# ANAL-iteracion2
Autores : Victoria Pelayo e Ignacio Rabuñal
