/**
 *
 * Descripcion: Implementacion de funciones de ordenacion 
 *
 * Fichero: ordenacion.c
 * Autor:Jesus D. Franco y Maria Barroso 
 * Version: 1.0
 * Fecha: 16-09-2016
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "ordenacion.h"

void swap2(int *p, int *q)
{
  int d = *p;
  *p = *q;
  *q = d;
}

/***************************************************/
/* Funcion: InsertSort Fecha:                      */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que ordena una tabla segun el metodo de  */
/* insercion (InserSort)                           */ 
/*                                                 */
/* Entrada:                                        */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int in: ultimo elemento de la tabla             */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/

int InsertSort(int* tabla, int ip, int iu)
{
  int i,j,a, nob=0;
  for(i=ip+1; i<=iu;i++){
      a = tabla[i];
      j = i-1;
      while(j>=ip && tabla[j]>a){
          tabla[j+1] = tabla[j];
          j--;
          nob++;
      }
      /*Para las veces que no entra en el bucle while*/
      nob++;
      tabla[j+1] = a;
  }
  return nob;
}

/***************************************************/
/* Funcion: InsertSortInv Fecha:                   */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que ordena una tabla en orden inverso    */
/* segun el metodo de insercion (InserSort)        */
/*                                                 */
/* Entrada:                                        */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int in: ultimo elemento de la tabla             */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/

int InsertSortInv(int* tabla, int ip, int iu)
{
  int i,j,a, nob=0;
  for(i=ip+1; i<=iu;i++){
      a = tabla[i];
      j = i-1;
      while(j>=ip && tabla[j]<a){
          tabla[j+1] = tabla[j];
          j--;
          nob++;
      }
      /*Para las veces que no entra en el bucle while*/
      nob++;
      tabla[j+1] = a;
  }
  return nob;
    
}

/***************************************************/
/* Funcion: mergesort Fecha:                       */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que ordena una tabla segun el metodo     */
/* de insercion (mergesort)                        */
/*                                                 */
/* Entrada:                                        */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int iu: ultimo elemento de la tabla             */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/

int mergesort(int* tabla, int ip, int iu)
{
  int m, nob1, nob2, nob3;
  assert(tabla != NULL);
  if(ip>iu)
    return ERR;
  if(ip==iu) /*tabla con un elemento*/
    return 0;
  else
    m = (ip+iu)/2;
  nob1 = mergesort(tabla,ip,m);
  if(nob1 == ERR)
    return ERR;
  nob2 = mergesort(tabla,m+1,iu);
  if(nob2 == ERR)
    return ERR;
  nob3 = merge(tabla,ip,iu,m);  
  if(nob3 == ERR)
    return ERR;  
  return nob1 + nob2 + nob3;
}

/***************************************************/
/* Funcion: merge Fecha:                           */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que combina los elementos de las         */
/* subtablas creadas por el algoritmo mergesort.   */
/*                                                 */
/* Entrada:                                        */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int iu: ultimo elemento de la tabla             */
/* int imedio: elemento medio de la tabla          */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/

int merge(int* tabla, int ip, int iu, int imedio)
{
  int * tablaAux;
  int i,j,k,n,ob=0;
  assert(tabla != NULL);
  n = (iu-ip+1);
  tablaAux = (int*)malloc(n*sizeof(tablaAux[0]));
  if(tablaAux == NULL)
    return ERR;
  i=ip;
  j=imedio+1;
  k=0;
  while(i<=imedio && j<=iu){
    if(tabla[i]<tabla[j]){
      tablaAux[k]=tabla[i];
      i++;
    }
    else{
      tablaAux[k]=tabla[j];
      j++;
    }
    k++;
    ob++;
  }
  if(i>imedio)
    while(j<=iu){
      tablaAux[k]=tabla[j];
      j++;
      k++;
    }
  else if(j>iu)
    while(i<=imedio){
      tablaAux[k]=tabla[i];
      i++;
      k++;
    }
    
  tablaAux -= ip;
  for(i=ip; i<=iu; i++)
    tabla[i]=tablaAux[i]; 
  tablaAux += ip;
  
  free(tablaAux);
  return ob;
  
}

/***************************************************/
/* Funcion: medio Fecha:                           */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que devuelve como pivote el elemento     */
/* situado en la primera posición de la tabla.     */
/*                                                 */
/* Entrada:                                        */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int iu: ultimo elemento de la tabla             */
/* int *pos: posición del pivote                   */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/

int medio(int *tabla, int ip, int iu, int *pos)
{
  assert(tabla != NULL);
  assert(pos != NULL);
  *pos = ip;
  return 0;
}

/***************************************************/
/* Funcion: medio_avg Fecha:                       */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que devuelve como pivote el elemento     */
/* situado en la última posición de la tabla.      */
/*                                                 */
/* Entrada:                                        */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int iu: ultimo elemento de la tabla             */
/* int *pos: posición del pivote                   */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/

int medio_avg(int *tabla, int ip, int iu, int *pos)
{
  assert(tabla != NULL);
  assert(pos != NULL);
  *pos = (ip+iu)/2;
  return 0;
}

/***************************************************/
/* Funcion: mediana Fecha:                         */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina complementaria a medio_stat, que calcula */      
/* la mediana entre tres números que se pasan como */
/* argumentos de entrada. Devuelve el valor medio  */
/* mediante un puntero a entero. Devuelve el número*/
/* de OBs.                                         */
/*                                                 */
/* Entrada:                                        */
/* int a, b, c: elementos a comparar               */
/* int *pos: posición del pivote                   */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/

int mediana(int* tabla, int ip, int m, int iu, int* pos)
{
  int a, b, c;
  int ob=0;
  a = tabla[ip];
  b = tabla[m];
  c = tabla[iu];
  if(a<=b){
    ob++;
    if(a>c){
      ob++;
      *pos = ip;
    }  
    else if(c<=b){
      ob += 2;
      *pos = iu;
    }  
    else{
      ob += 2;
      *pos = m;
    }
  }
  else {
    ob ++;
    if(a<=c){
      ob++;
      *pos = ip; 
    }
    else if(b>=c){
      ob += 2;
      *pos = m;
    }
    else {
      ob += 2;
      *pos = iu;
    }
  }
  return ob;
}

/***************************************************/
/* Funcion: medio_stat Fecha:                      */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que que compara los valores de las       */      
/* posiciones ip,iu e (ip+ iu)/2 y devuelve como   */
/* pivote la posición que contenga el valor        */
/* intermedio entre las tres.                      */
/*                                                 */
/* Entrada:                                        */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int iu: ultimo elemento de la tabla             */
/* int *pos: posición del pivote                   */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/

int medio_stat(int *tabla, int ip, int iu, int *pos)
{
  int m;
  assert(tabla != NULL);
  assert(pos != NULL);
  m = (ip+iu)/2;
  return mediana(tabla, ip, m, iu, pos);
}

/***************************************************/
/* Funcion: partir1    Fecha:                      */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que calcula la relación entre el pivote  */
/* calculado previamente según el método usado, y  */
/* los elementos de la tabla, siguiendo el         */
/* el pseudicódigo de las diapositivas.            */
/*                                                 */
/* Entrada:                                        */
/* pfunc_medio medio: rutina para elegir pivote    */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int in: ultimo elemento de la tabla             */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/

int partir1(pfunc_medio medio, int* tabla, int ip, int iu, int* pos)
{
  int i, k, ob = 0;
  assert (pos != NULL);
  ob += medio(tabla, ip, iu, pos);
  k = tabla[*pos];
  swap2(&tabla[ip], &tabla[*pos]);
  *pos = ip;
  for(i = ip+1; i<= iu; i++){
    if(tabla[i]<k){
      (*pos)++;
      swap2(&tabla[i], &tabla[*pos]);
    }
    ob++;
  }
  swap2(&tabla[ip], &tabla[*pos]);
  return ob;
}
/***************************************************/
/* Funcion: partir    Fecha:                       */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que calcula la relación entre el pivote  */
/* calculado previamente según el método usado, y  */
/* los elementos de la tabla, siguiendo el         */
/* el pseudicódigo de las diapositivas.            */
/*                                                 */
/* Entrada:                                        */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int in: ultimo elemento de la tabla             */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/
int partir(int* tabla, int ip, int iu,int *pos)
{
  int i, k, ob = 0;
  assert (pos != NULL);
  /*ob += medio(tabla, ip, iu, pos);*/
  /*ob += medio_avg(tabla, ip, iu, pos);*/
  ob += medio_stat(tabla, ip, iu, pos);
  k = tabla[*pos];
  swap2(&tabla[ip], &tabla[*pos]);
  *pos = ip;
  for(i = ip+1; i<= iu; i++){
    if(tabla[i]<k){
      (*pos)++;
      swap2(&tabla[i], &tabla[*pos]);
    }
    ob++;
  }
  swap2(&tabla[ip], &tabla[*pos]);
  return ob;
}

/***************************************************/
/* Funcion: quicksort Fecha:                       */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que ordena una tabla segun el metodo     */
/* de insercion (quicksort)                        */
/*                                                 */
/* Entrada:                                        */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int in: ultimo elemento de la tabla             */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/

int quicksort(int* tabla, int ip, int iu)
{
  int m, ob = 0, a;
  assert (tabla != NULL);
  if(ip>iu)
    return ERR;
  if(ip==iu)
    return ob;
  a = partir(tabla, ip, iu, &m);
    if (a == ERR)
      return ob;
  ob += a;
  if(ip < m-1){
    a = quicksort(tabla, ip, m-1);
    if (a == ERR)
      return ob;
    ob += 1 + a;
  }  
  if(m+1 < iu){
    a = quicksort(tabla, m+1, iu);
    if (a == ERR)
      return ob;
    ob += 1 + a;
  }  
  return ob;
}

/***************************************************/
/* Funcion: quicksort1 Fecha:                       */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que ordena una tabla segun el metodo     */
/* de insercion (quicksort)                        */
/*                                                 */
/* Entrada:                                        */
/* pfunc_medio medio: rutina para elegir pivote    */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int in: ultimo elemento de la tabla             */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la ob       */  
/***************************************************/

int quicksort1(pfunc_medio medio, int* tabla, int ip, int iu)
{
  int m, ob = 0, a;
  assert (tabla != NULL);
  if(ip>iu)
    return ERR;
  if(ip==iu)
    return ob;
  a = partir1(medio, tabla, ip, iu, &m);
  if (a == ERR)
      return ob;
  ob += a;
  if(ip < m-1){
    a = quicksort1(medio, tabla, ip, m-1);
    if (a == ERR)
      return ob;
    ob += 1 + a;
  }  
  if(m+1 < iu){
    a = quicksort1(medio, tabla, m+1, iu);
    if (a == ERR)
      return ob;
    ob += 1 + a;
  }  
  return ob;
}