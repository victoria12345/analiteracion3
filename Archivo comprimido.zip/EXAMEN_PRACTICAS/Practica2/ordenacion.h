/**
 *
 * Descripcion: Funciones de cabecera para ordenacion 
 *
 * Fichero: ordenacion.h
 * Autor: Jesus D. Franco y Maria Barroso 
 * Version: 1.0
 * Fecha: 16-09-2016
 *
 */

#ifndef ORDENACION_H
#define ORDENACION_H

/* constantes */

#ifndef ERR
  #define ERR -1
  #define OK (!(ERR))
#endif

/* definiciones de tipos */
typedef int (* pfunc_ordena)(int*, int, int);
typedef int (* pfunc_medio)(int*, int, int, int*);
/* Funciones */

int InsertSort(int* tabla, int ip, int iu);
int InsertSortInv(int* tabla, int ip, int iu);

int mergesort(int* tabla, int ip, int iu);
int merge(int* tabla, int ip, int iu, int imedio);
int quicksort(int* tabla, int ip, int iu);
int quicksort1(pfunc_medio metodo, int* tabla, int ip, int iu);
int partir1(pfunc_medio metodo, int* tabla, int ip, int iu, int* pos);
int partir(int* tabla, int ip, int iu,int *pos);
int medio(int *tabla, int ip, int iu, int *pos);
int medio_avg(int *tabla, int ip, int iu, int *pos);
int medio_stat(int *tabla, int ip, int iu, int *pos);
int mediana(int* tabla, int ip, int m, int iu, int* pos);
/*int mediana(int a, int b, int c, int ob);*/
#endif
