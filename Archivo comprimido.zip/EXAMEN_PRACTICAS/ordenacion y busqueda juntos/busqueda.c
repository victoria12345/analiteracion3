#include "busqueda.h"
/**
 *
 * Descripcion: Implementacion de funciones de busqueda
 *
 * Fichero: busqueda.c
 * Autor: Jesus D. Franco y Maria Barroso 
 * Version: 1.0
 * Fecha: 16-09-2016
 *
 */
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>


/*
 *  Funciones de geracion de claves
 *
 *  Descripcion: Recibe el numero de claves que hay que generar
 *               en el parametro n_claves. Las claves generadas
 *               iran de 1 a max. Las claves se devuelven en 
 *               el parametro claves que se debe reservar externamente
 *               a la funcion.
 */ 
  
/**
 *  Funcion: generador_claves_uniforme
 *               Esta fucnion genera todas las claves de 1 a max de forma 
 *               secuencial. Si n_claves==max entonces se generan cada clave
 *               una unica vez.
 */
void generador_claves_uniforme(int *claves, int n_claves, int max)
{
  int i;

  for(i = 0; i < n_claves; i++) claves[i] = 1 + (i % max);

  return;
}

/*
 *  Funcion: generador_claves_potencial
 *               Esta funcion genera siguiendo una distribucion aproximadamente
 *               potencial. Siendo los valores mas pequenos mucho mas probables
 *               que los mas grandes. El valor 1 tiene una probabilidad del 50%,
 *               el dos del 17%, el tres el 9%, etc.
 */
void generador_claves_potencial(int *claves, int n_claves, int max)
{
  int i;

  for(i = 0; i < n_claves; i++) {
    claves[i] = (1+max) / (1 + max*((double)rand()/RAND_MAX));
  }

  return;
}

/***************************************************/
/* Funcion: ini_diccionario                        */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que crea un diccionario vacío del tipo   */
/* indicado por sus argumentos.                    */
/*                                                 */
/* Entrada:                                        */
/* int tamanio: tamaño inicial que deseamos darle  */
/* al diccionario                                  */
/* char orden: de tipo ORDENADO o NO ORDENADO si   */
/* se emplea una tabla ordenada o desordenada como */
/* estructura de datos                             */
/* Salida:                                         */
/* PDICC: diccionario creado                       */
/***************************************************/

PDICC ini_diccionario (int tamanio, char orden)
{
	PDICC diccionario;
	assert(tamanio >= 0);
	assert(orden == ORDENADO || orden == NO_ORDENADO);
	diccionario = (PDICC)malloc(sizeof(diccionario[0]));
	if (diccionario == NULL)
	    return NULL;
	diccionario->tamanio = tamanio;
	diccionario->n_datos = 0;
	diccionario->orden = orden;
	diccionario->tabla = (int*)malloc(tamanio*sizeof(diccionario->tabla[0]));
	if (diccionario->tabla == NULL){
	    free(diccionario);
	    return NULL;
	}
	return diccionario;
}

/***************************************************/
/* Funcion: libera_diccionario                     */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que libera un diccionario                */
/*                                                 */
/* Entrada:                                        */
/* PDICC pdicc: diccionario a liberar              */
/* Salida:                                         */
/* void                                            */
/***************************************************/

void libera_diccionario(PDICC pdicc)
{
	if(pdicc != NULL){
	    free(pdicc->tabla);
	    free(pdicc);
	}
}

/***************************************************/
/* Funcion: inserta_diccionario                    */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que inserta una clave en la posicion     */
/* correcta de un diccionario, si esta desordenado */
/* lo insertará al final, y si está ordenado en su */
/* respectiva posición                             */ 
/*                                                 */
/* Entrada:                                        */
/* PDICC pdicc: diccionario no lleno               */
/* int clave: clave a insertar                     */
/* Salida:                                         */
/* int: numero de operaciones básicas              */
/***************************************************/

int inserta_diccionario(PDICC pdicc, int clave)
{
	int j, ob=0;
	assert(pdicc != NULL);
	assert(pdicc->orden == NO_ORDENADO || pdicc->orden == ORDENADO);
	if(pdicc->n_datos>=pdicc->tamanio)
		return ERR;
	j=pdicc->n_datos;	
	pdicc->tabla[pdicc->n_datos] = clave;
	pdicc->n_datos++;
	if(pdicc->orden == NO_ORDENADO) return ob;
	j--;
	while(j>=0 && (pdicc->tabla[j]>clave)){
		ob++;
		pdicc->tabla[j+1] = pdicc->tabla[j];
		j--;
	}
	pdicc->tabla[j+1] = clave;
	return ob;

}

/***************************************************/
/* Funcion: insercion_masiva_diccionario           */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que inserta una clave en un un           */
/* diccionario mediante sucesivas llamas a la      */
/* función inserta diccionario                     */
/*                                                 */
/* Entrada:                                        */
/* PDICC pdicc: diccionario no lleno               */
/* int * clave: claves a insertar                  */
/* int n_clave: numero total de claves             */
/* Salida:                                         */
/* int: numero de operaciones básicas              */
/***************************************************/

int insercion_masiva_diccionario (PDICC pdicc,int *claves, int n_claves)
{
    int i, ob=0, control;
	assert(pdicc!=NULL);
	assert(claves!=NULL);
	assert(n_claves>0);
	for(i = 0; i < n_claves; i++){
	    control=inserta_diccionario(pdicc, claves[i]);
	    if(control==ERR)
	    	return ERR;
	    ob+=control;
	}
	return ob;
}

/***************************************************/
/* Funcion: busca_diccionario                      */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que busca una clave en un                */
/* diccionario mediante una rutina determinada     */
/*                                                 */
/* Entrada:                                        */
/* PDICC pdicc: diccionario                        */
/* int clave: clave a buscar                       */
/* int *ppos: posición de la clave                 */
/* pfunc_busqueda metodo: rutina de búsqueda       */
/* Salida:                                         */
/* int: numero de operaciones básicas              */
/***************************************************/

int busca_diccionario(PDICC pdicc, int clave, int *ppos, pfunc_busqueda metodo)
{
    assert(pdicc != NULL);
    assert(ppos != NULL);
    return metodo(pdicc->tabla, 0, pdicc->n_datos-1, clave, ppos);
}

/***************************************************/
/* Funcion: imprime_diccionario                    */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que imprime un diccionario               */
/*                                                 */
/* Entrada:                                        */
/* PDICC pdicc: diccionario                        */
/* Salida:                                         */
/* void                                            */
/***************************************************/

void imprime_diccionario(PDICC pdicc)
{
	int i=0;
	while (i < pdicc->n_datos){
		printf("%d ", pdicc->tabla[i]);
		i++;
	}	
	printf("\n");
}

/***************************************************/
/* Funcion: bbin                                   */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina de búsqueda que busca un elemento o      */
/* clave pasado como argumento según el método     */
/* de búsqueda binaria por recursión.              */    
/*                                                 */
/* Entrada:                                        */
/* int* tabla: tabla de elementos en la que        */
/* queremos buscar nuestra clave                   */
/* int P: primera posicion de la tabla a buscar    */
/* int U: última posición de la tabla a buscar     */
/* int clave: elemento que queremos encontrar      */
/* int *ppos: puntero a entero en el que guardamos */
/* la posicion de la clave en la tabla             */
/* Salida:                                         */
/* Nómero de OBs realizadas si se ha hecho de      */
/* manera correcta y posicion en la que se         */
/* encuentra la clave que buscamos. ERR si se ha   */
/* producido algún error, NO_ENCONTRADO en ppos    */
/***************************************************/

int bbin(int *tabla,int P,int U,int clave,int *ppos)
{
	int m, a, ob = 0;
	assert(tabla!=NULL || ppos!=NULL);
	assert(P>=0 || U>=0);
	*ppos = NO_ENCONTRADO;
	if (P<=U){
		m = (P+U)/2;
		ob++;
		if (tabla[m]==clave){
			*ppos = m;
			return ob;
		}
		ob++;
		if (clave < tabla[m]){
			a = bbin(tabla, P, m-1, clave, ppos);
			if(a != ERR)
				return ob += a;
			return ERR;	
		}
		else{
			a = bbin(tabla, m+1, U, clave, ppos);
			if(a != ERR)
				return ob += a;
			return ERR;	
		}
	}
	/*aquí devolvemos ERR porque U>P, y esto no se puede dar en una tabla*/
	return ERR;
}

/***************************************************/
/* Funcion: blin                                   */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina de búsqueda que busca un elemento o      */
/* clave pasado como argumento según el método     */
/* de búsqueda lineal                              */    
/*                                                 */
/* Entrada:                                        */
/* int* tabla: tabla de elementos en la que        */
/* queremos buscar nuestra clave                   */
/* int P: primera posicion de la tabla a buscar    */
/* int U: última posición de la tabla a buscar     */
/* int clave: elemento que queremos encontrar      */
/* int *ppos: puntero a entero en el que guardamos */
/* la posicion de la clave en la tabla             */
/* Salida:                                         */
/* Nómero de OBs realizadas si se ha hecho de      */
/* manera correcta y posicion en la que se         */
/* encuentra la clave que buscamos. ERR si se ha   */
/* producido algún error, NO_ENCONTRADO en ppos    */
/***************************************************/

int blin(int *tabla,int P,int U,int clave,int *ppos)
{
	int i, ob = 0;
	assert(tabla!=NULL || ppos!=NULL);
	assert(P>=0 || U>=0);
	if(P>U){
		*ppos = NO_ENCONTRADO;
		return ob;
	}
	for (i=P; i<=U; i++){
		ob ++;
		if(tabla[i]==clave){
			*ppos = i;
			return ob;
		}
	}
	*ppos = NO_ENCONTRADO;
	return ob;
}

/***************************************************/
/* Funcion: blin                                   */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina de búsqueda que busca un elemento o      */
/* clave pasado como argumento según el método     */
/* de búsqueda lineal automatizada.                */    
/*                                                 */
/* Entrada:                                        */
/* int* tabla: tabla de elementos en la que        */
/* queremos buscar nuestra clave                   */
/* int P: primera posicion de la tabla a buscar    */
/* int U: última posición de la tabla a buscar     */
/* int clave: elemento que queremos encontrar      */
/* int *ppos: puntero a entero en el que guardamos */
/* la posicion de la clave en la tabla             */
/* Salida:                                         */
/* Nómero de OBs realizadas si se ha hecho de      */
/* manera correcta y posicion en la que se         */
/* encuentra la clave que buscamos. ERR si se ha   */
/* producido algún error, NO_ENCONTRADO en ppos    */
/***************************************************/

int blin_auto(int *tabla,int P,int U,int clave,int *ppos)
{
	int i,j,aux,ob=0;
	assert(tabla != NULL);
	assert(P>=0 || U>=0);
	assert(ppos != NULL);
	for (i=P; i<=U; i++){
		ob ++;
		if(tabla[i]==clave){
			*ppos = i;
			if(i>0){
				j=i-1;
				aux = tabla[j];
				tabla[j] = clave;
				tabla[i] = aux;
				*ppos = j;
			}
			return ob;
		}
	}
	*ppos= NO_ENCONTRADO;
	return ob;
}

