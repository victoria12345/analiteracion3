/**
 *
 * Descripcion: Implementacion de funciones de ordenacion 
 *
 * Fichero: ordenacion.c
 * Autor:Jesus D. Franco y Maria Barroso 
 * Version: 1.0
 * Fecha: 16-09-2016
 *
 */


#include "ordenacion.h"

/***************************************************/
/* Funcion: InsertSort Fecha:                      */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que ordena una tabla segun el metodo de  */
/* insercion (InserSort)                           */ 
/*                                                 */
/* Entrada:                                        */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int in: ultimo elemento de la tabla             */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la oB       */  
/***************************************************/

int InsertSort(int* tabla, int ip, int iu)
{
  int i,j,a, nob=0;
  for(i=ip+1; i<=iu;i++){
      a = tabla[i];
      j = i-1;
      while(j>=ip && tabla[j]>a){
          tabla[j+1] = tabla[j];
          j--;
          nob++;
      }
      /*Para las veces que no entra en el bucle while*/
      nob++;
      tabla[j+1] = a;
  }
  return nob;
}

/***************************************************/
/* Funcion: InsertSortInv Fecha:                   */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que ordena una tabla en orden inverso    */
/* segun el metodo de insercion (InserSort)        */
/*                                                 */
/* Entrada:                                        */
/* int *tabla: tabla a ordenar                     */
/* int ip: primer elemento de la tabla             */
/* int in: ultimo elemento de la tabla             */
/* Salida:                                         */
/* int: numero de veces que se ejecuta la oB       */  
/***************************************************/
int InsertSortInv(int* tabla, int ip, int iu)
{
  int i,j,a, nob=0;
  for(i=ip+1; i<=iu;i++){
      a = tabla[i];
      j = i-1;
      while(j>=ip && tabla[j]<a){
          tabla[j+1] = tabla[j];
          j--;
          nob++;
      }
      /*Para las veces que no entra en el bucle while*/
      nob++;
      tabla[j+1] = a;
  }
  return nob;
    
}

