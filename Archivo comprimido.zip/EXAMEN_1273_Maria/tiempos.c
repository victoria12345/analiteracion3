/**
 *
 * Descripcion: Implementacion de funciones de tiempo
 *
 * Fichero: tiempos.c
 * Autor: Jesus D. Franco y Maria Barroso 
 * Version: 1.0
 * Fecha: 16-09-2016
 *
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include "tiempos.h"
#include "ordenacion.h"
#include "permutaciones.h"


/***************************************************/
/* Funcion: tiempo_medio_ordenacion                */
/* Fecha: 07/10/2016                               */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que calcula el tiempo medio de           */
/* ordenación de una tabla                         */
/*                                                 */
/* Entrada:                                        */
/* pfunc_ordena metodo: algoritmo de ordenación    */
/*			int n_perms: numero de permutaciones a */
/* generar y ordenar                               */
/*			int tamanio: tamaño de cada permutación*/
/*			PTIEMPO ptiempo: puntero a estructura  */
/* de tipo TIEMPO que contendrá el número de       */
/* permutaciones promediadas                       */
/* Salida:                                         */
/* OK en caso de correcta ordenacion de tiempos    */
/* NULL en caso de error                           */
/***************************************************/
short tiempo_medio_ordenacion(pfunc_ordena metodo,
                              int n_perms,
                              int tamanio, 
                              PTIEMPO ptiempo)
{
	int i, ob;
	clock_t ini, fin;
	int **perms = genera_permutaciones(n_perms, tamanio);
	if (perms==NULL)
		return ERR;
	ptiempo->tiempo = 0.0;
	ptiempo->min_ob = INT_MAX;
	ptiempo->max_ob = 0;
	ptiempo->medio_ob = 0;
	ini = clock();
	for (i=0; i < n_perms; i++){
		ob = metodo(perms[i], 0, tamanio-1);
		if(ob==ERR){
			while(i<=0){
				free(perms[i]);
				i--;
			}
			free(perms);
		}
		if(ob<ptiempo->min_ob)
			ptiempo->min_ob = ob;
		if(ob>ptiempo->max_ob)
			ptiempo->max_ob = ob;
		ptiempo->medio_ob +=ob;
		
	}
	fin = clock();
	ptiempo->tiempo = (double)(fin-ini)/n_perms/CLOCKS_PER_SEC;
	ptiempo->tamanio= tamanio;
	ptiempo->medio_ob/= n_perms;
	for(i=0;i<n_perms;i++)
		free(perms[i]);
	free(perms);
	
	return OK; 
}

/***************************************************/
/* Funcion: genera_tiempos_ordenacion              */
/* Fecha: 07/10/2016                               */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/* Rutina que escribe en el fichero fichero los    */
/* tiempos medios, y los números promedio, mínimo  */
/* y máximo de veces que se ejecuta la OB en el    */
/* algoritmo de ordenación                         */
/*                                                 */
/* Entrada:                                        */
/* pfunc_ordena metodo: algoritmo de ordenación    */
/*			char* fichero: fichero en el que se    */
/* escribe                                         */
/*			int num_min: rango en el que comienzan */
/* el tamaño de las permutaciones                  */
/*			int num_min: rango en el que finalizan */
/* el tamaño de las permutaciones                  */
/*			int incr: incremento del rango         */
/*			int n_perms: numero de permutaciones a */
/* generar y ordenar                               */			
/* Salida:                                         */
/* OK en caso de correcta generacion de tiempos    */
/* NULL en caso de error                           */
/***************************************************/

short genera_tiempos_ordenacion(pfunc_ordena metodo, char* fichero, int num_min, int num_max, int incr, int n_perms)
{
	int i, N = (((num_max-num_min)/incr)+1);
	PTIEMPO tiempo = (PTIEMPO)malloc(N*sizeof(TIEMPO));
	if (tiempo == NULL)
		return ERR;
	for(i= 0; i < N; i++)
		if(tiempo_medio_ordenacion(metodo, n_perms, i*incr + num_min, tiempo+i)==ERR){
			free(tiempo);
			return ERR;
		}
	if((guarda_tabla_tiempos(fichero, tiempo, N)==ERR)){
			free(tiempo);
			return ERR;
	}
	free(tiempo);
	return OK;
}

/***************************************************/
/* Funcion: guarda_tabla_tiempos                   */
/* Fecha: 12/10/2016                               */
/* Autores: María Barroso y Jesús D. Franco        */
/*                                                 */
/*Rutina que imprime en el fichero fichero el      */
/*tamaño de cada permutación,el tiempo de ejecución*/
/*y el número promedio, máximo y mínimo que se     */
/*ejecuta la OB. Esto se imprime a partir de       */
/*ptiempo, un array de tamaño N                    */
/*                                                 */
/* Entrada:                                        */
/*-char* fichero: fichero en el que se             */
/* escribe                                         */
/*-PTIEMPO tiempo: array de tamaño N del que se    */
/*toman los datos a imprimir                       */
/*-int N: tamaño del array tiempo                  */			
/* Salida:                                         */
/* OK en caso de correcta impresión de tiempos     */
/* NULL en caso de error                           */
/***************************************************/
short guarda_tabla_tiempos(char* fichero, PTIEMPO tiempo, int N)
{
	int i;
	FILE *f =fopen(fichero, "w");
	if(f==NULL)
		return ERR;
	for (i=0; i<N; i++)
		fprintf(f, "%d \t%f \t%f \t%d \t%d \n",tiempo[i].tamanio, tiempo[i].tiempo,tiempo[i].medio_ob,tiempo[i].max_ob,tiempo[i].min_ob);
	fclose(f);
	return OK;
}
